# 🏦 FinRisk Suite — Credit & Risk Analytics Platform

Plataforma de analítica de crédito y riesgo construida con **Streamlit + scikit-learn + XGBoost + LightGBM + SHAP**.  
Todos los modelos son explicables (SHAP), calibrados y documentados para uso demostrativo/portafolio.

---

## 📁 Estructura del proyecto

```
credit_risk_app/
├── app.py                         # Página de inicio y navegación
├── requirements.txt
├── .streamlit/
│   └── config.toml                # Tema y configuración del servidor
├── utils/
│   ├── __init__.py
│   └── helpers.py                 # Generadores de datos, constructores de modelos, gráficas
└── pages/
    ├── 1_📊_Scoring_Credito.py    # XGBoost + SHAP — aprobación crediticia
    ├── 2_⚠️_Prediccion_Default.py # LightGBM + SMOTE — PD a 12 meses
    ├── 3_🔍_Deteccion_Fraude.py   # Random Forest + SMOTE — fraude en transacciones
    ├── 4_🏢_Rating_Corporativo.py # XGBoost multiclase — AAA/AA/A/BBB
    ├── 5_🚨_AML_Lavado_Dinero.py  # XGBoost + reglas — lavado de dinero
    └── 6_📈_Stress_Test.py        # Monte Carlo — stress test de portafolio
```

---

## ⚙️ Instalación y ejecución local

```bash
# 1. Clonar / descomprimir el proyecto
cd credit_risk_app

# 2. Crear entorno virtual (recomendado)
python -m venv .venv
source .venv/bin/activate        # Linux/Mac
# .venv\Scripts\activate         # Windows

# 3. Instalar dependencias
pip install -r requirements.txt

# 4. Ejecutar
streamlit run app.py
# → Abre http://localhost:8501
```

---

## 🧩 Módulos y modelos

| Módulo | Modelo | Técnica especial | Métrica clave |
|--------|--------|-----------------|---------------|
| Scoring de Crédito | XGBoost | SHAP explicabilidad | AUC-ROC |
| Predicción de Default | LightGBM | SMOTE (desbalance) | AUC + PR Curve |
| Detección de Fraude | Random Forest | SMOTE + umbral ajustable | Average Precision |
| Rating Corporativo | XGBoost multiclase | Radar chart perfil | Accuracy |
| AML — Lavado de Dinero | XGBoost | scale_pos_weight + reglas | AUC-ROC |
| Stress Test | Monte Carlo | Shocks paramétricos | VaR 95/99, CVaR |

---

## 🔧 Stack tecnológico (todo open source / capa gratuita)

| Componente | Librería |
|-----------|----------|
| Frontend / UI | Streamlit |
| Modelos ML | XGBoost, LightGBM, scikit-learn |
| Balanceo de clases | imbalanced-learn (SMOTE) |
| Explicabilidad | SHAP |
| Visualizaciones | Plotly |
| Data wrangling | Pandas, NumPy |

---

## 🚀 Despliegue (próximos pasos)

- **Streamlit Community Cloud** — gratuito, solo conectar repositorio GitHub
- **Railway / Render** — capa gratuita, para mayor control
- **Docker** — containerización para producción

---

## 📌 Notas

- Todos los datos son **sintéticos** generados con semillas fijas (reproducibles).
- Los modelos se entrenan al iniciar la app y se cachean con `@st.cache_data`.
- Para producción: reemplazar generadores con conexiones a bases de datos reales.
